const toDoForm = document.querySelector(".js-toDoForm"),
  toDoInput = toDoForm.querySelector(".js-form__todo"),
  toDoList = document.querySelector(".js-toDoList");

const TODO_LS = "toDos";

let toDos = [];

function deleteToDo(event) {
  console.log(event.target);
  const btn = event.target;
  const li = btn.parentNode;
  console.log(li);
  console.log(toDoList.removeChild("li"));
  toDoList.removeChild(li);
  const cleanToDos = toDos.filter(function (toDo) {
    return toDo.id !== parseInt(li.id);
  });
  toDos = cleanToDos;
  saveToDos();
}

function saveToDos() {
  localStorage.setItem(TODO_LS, JSON.stringify(toDos));
}

function paintToDo(text) {
  const li = document.createElement("li");
  const delBtn = document.createElement("button");
  const div = document.createElement("div");
  const newId = toDos.length + 1;
  const btnImage = document.createElement("img");
  btnImage.src = "images/btn.png";
  btnImage.id = "btnImage";
  div.setAttribute("class", "todo_task");
  delBtn.appendChild(btnImage);
  delBtn.addEventListener("click", deleteToDo);
  delBtn.setAttribute("class", "delBtn");
  div.innerText = text;
  li.appendChild(delBtn);
  li.appendChild(div);
  li.setAttribute("class", "todo_list");
  li.id = newId;
  toDoList.appendChild(li);
  const toDoObj = {
    text: text,
    id: newId,
  };
  toDos.push(toDoObj);
  saveToDos();
}

function handleSubmit(event) {
  event.preventDefault();
  const currentValue = toDoInput.value;
  paintToDo(currentValue);
  toDoInput.value = "";
}

function loadToDos() {
  const loadedToDos = localStorage.getItem(TODO_LS);
  if (loadedToDos !== null) {
    const parsedToDos = JSON.parse(loadedToDos);
    parsedToDos.forEach(function (toDo) {
      paintToDo(toDo.text);
    });
  }
}

function init() {
  loadToDos();
  toDoForm.addEventListener("submit", handleSubmit);
}

init();
